package version_01;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings("serial")
public class TabClass2 extends TabAeptor {
	private JTable table1, table2;
	private JScrollPane scroll1, scroll2;
	private JLabel la1, la2;
	private JButton bt_ok, bt_fa, bt_del, bt_fa2, bt_all, bt_go, bt_go2, bt_all2;
	public JButton bt_re;
	private JPanel p1, p2, p3, p4, cardp, cardp2;
	public JPanel p_main;
	private Font f1;
	private CardLayout card;
	private String ID;
	private String[] title = { "�� ȣ", "�� �� ��", "�� �� ��", "�� ¥" };
	private String[][] data;
	private DefaultTableModel model1, model2;
	boolean table = true, panel = true, alpa;
	public JTabbedPane tab;
	private TabClass tc1;
	private Color c = new Color(204, 204, 255);
	private Color c2 = new Color(204, 255, 204);


	public TabClass2(String ID) {

		bt_ok = new JButton("�� ��");
		bt_fa = new JButton("���ã��");
		bt_fa2 = new JButton("�� ��");
		bt_del = new JButton("�� ��");
		bt_re = new JButton();
		bt_go = new JButton("ã ��");
		bt_go2 = new JButton("ã ��");
		bt_all = new JButton("�� �� ȭ");
		bt_all2 = new JButton("�� �� ȭ");
		p_main = new JPanel();
		p1 = new JPanel();
		p2 = new JPanel();
		p3 = new JPanel();
		p4 = new JPanel();
		cardp = new JPanel();
		cardp2 = new JPanel();
		f1 = new Font("����", Font.PLAIN, 20);
		card = new CardLayout();
		this.ID = ID;

		model2 = new DefaultTableModel(title, 0) {
			public boolean isCellEditable(int i, int c) {
				return false;
			}
		};
		model1 = new DefaultTableModel(title, 0) {
			public boolean isCellEditable(int i, int c) {
				return false;
			}
		};

		this.Pmain();
	}

	public TabClass2(String ID, JTabbedPane tab, TabClass tc1) {
		this(ID);
		this.tab = tab;
		this.tc1 = tc1;
	}

	public void Panel1() {
		if (table != true)
			table = !table;
		p1.setBackground(c);
		table1 = new JTable(model1);
		scroll1 = new JScrollPane(table1);
		scroll1.setPreferredSize(new Dimension(800, 470));
		table1.getTableHeader().setBackground(c2);


		table1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table1.getColumn("�� ȣ").setPreferredWidth(90);
		table1.getColumn("�� �� ��").setPreferredWidth(248);
		table1.getColumn("�� �� ��").setPreferredWidth(248);
		table1.getColumn("�� ¥").setPreferredWidth(200);

		table1.setRowHeight(40);
		table1.setFont(f1);

		table1.getTableHeader().setReorderingAllowed(false);
		table1.getTableHeader().setResizingAllowed(false);

		p1.add(scroll1);
		p1.setBounds(0, 0, 800, 500);

		table1.getTableHeader().setReorderingAllowed(false);
		table1.getTableHeader().setResizingAllowed(false);

		TableSET(table1);

	}

	public void Panel2() {
		if (table != false)
			table = !table;
		p2.setBackground(c);

		table2 = new JTable(model2);
		scroll2 = new JScrollPane(table2);
		scroll2.setPreferredSize(new Dimension(800, 470));
		table2.getTableHeader().setBackground(c2);


		table2.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table2.getColumn("�� ȣ").setPreferredWidth(90);

		table2.getColumn("�� �� ��").setPreferredWidth(248);
		table2.getColumn("�� �� ��").setPreferredWidth(248);
		table2.getColumn("�� ¥").setPreferredWidth(200);

		table2.setRowHeight(40);
		table2.setFont(f1);

		table2.getTableHeader().setReorderingAllowed(false);
		table2.getTableHeader().setResizingAllowed(false);

		p2.add(scroll2);
		p2.setBounds(0, 0, 800, 500);

		table2.getTableHeader().setReorderingAllowed(false);
		table2.getTableHeader().setResizingAllowed(false);

		TableSET(table2);
	}

	public void Panel3() {
		if (panel != true)
			panel = !panel;
		p3.setLayout(null);
		p3.setBackground(c);
		bt_ok.setBounds(200, 0, 200, 70);
		bt_fa.setBounds(200, 135, 200, 70);
		bt_all.setBounds(200, 270, 200, 70);
		bt_go.setBounds(200, 405, 200, 70);

		p3.add(bt_ok);
		p3.add(bt_fa);
		p3.add(bt_all);
		p3.add(bt_go);
	}

	public void Panel4() {
		if (panel != false)
			panel = !panel;
		p4.setLayout(null);
		p4.setBackground(c);

		bt_del.setBounds(200, 0, 200, 70);
		bt_fa2.setBounds(200, 135, 200, 70);
		bt_all2.setBounds(200, 270, 200, 70);
		bt_go2.setBounds(200, 405, 200, 70);

		p4.add(bt_del);
		p4.add(bt_fa2);
		p4.add(bt_all2);
		p4.add(bt_go2);
	}

	public void Panelcard() {

		cardp.setLayout(card);
		cardp.setBounds(100, 200, 800, 500);
		cardp.add(p1, "Record");
		cardp.add(p2, "favorit");
	}

	void Panelcard2() {
		cardp2.setLayout(card);
		cardp2.setBounds(900, 200, 500, 500);
		cardp2.add(p3, "Record");
		cardp2.add(p4, "favorit");
	}

	public void Pmain() {
		p_main.setLayout(null);
		p_main.setBackground(c);

		bt_re.setBounds(200, 600, 100, 100);
		bt_re.setVisible(false);
		p_main.add(bt_re);

		this.Print(la1, la2, p_main);
		this.ButtonEvent();
		bt_re.doClick();
		this.Panel1();
		this.Panel2();
		this.Panel3();
		this.Panel4();
		this.Panelcard();
		this.Panelcard2();
		p_main.add(cardp);
		p_main.add(cardp2);
		p_main.setBounds(10, 10, 1400, 700);
	}

	public void ReverseCard() {
		if (table == false && panel == false) {
			card.previous(cardp);
			card.previous(cardp2);
		} else {
			card.next(cardp);
			card.next(cardp2);
		}
	}

	void ComboSet(JTable table) {
		try {
			
			String start = (String) table.getValueAt(table.getSelectedRow(), 1);
			String goal = (String) table.getValueAt(table.getSelectedRow(), 2);
			JComboBox<String> jcb1 = tc1.combo1();
			JComboBox<String> jcb2 = tc1.combo2();
			
			jcb1.setSelectedItem(start);
			jcb2.setSelectedItem(goal);
			tab.setSelectedIndex(0);
		} catch (Exception e2) {
			JOptionPane.showMessageDialog(null, "����� ���õ��� �ʾҽ��ϴ�.", "�ҷ����� ����", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	
	public void ButtonEvent() {
		bt_fa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model2.setNumRows(0);
				ReverseCard();
				try {
					RecodDAO dao = new RecodDAO();
					ArrayList<RecodVO> rec2 = dao.rec2(ID);
					for (int i = 0; i < rec2.size(); i++) {
						RecodVO Data = (RecodVO) rec2.get(i);
						data = Data.getResult();
					}
					if (data == null) {
						JOptionPane.showMessageDialog(null, "�˻������ �����ϴ�.", "�ҷ����� ����", JOptionPane.ERROR_MESSAGE);
					} else {

						for (int i = data.length - 1; i >= 0; i--) {
							Object[] mod = new Object[data[0].length];
							for (int y = 0; y < data[i].length; y++) {
								mod[y] = data[i][y];
							}
							model2.addRow(mod);
						}

					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "�ý��� ����, ���ã�� �ҷ����� ����", "�ҷ����� ����", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		bt_fa2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model1.setNumRows(0);
				ReverseCard();
				bt_re.doClick();
			}
		});

		bt_re.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model1.setNumRows(0);
				try {
					RecodDAO dao = new RecodDAO();
					ArrayList<RecodVO> rec = dao.rec(ID);
					for (int i = 0; i < rec.size(); i++) {
						RecodVO Data = (RecodVO) rec.get(i);
						data = Data.getResult();
					}
					if (data == null) {
						JOptionPane.showMessageDialog(null, "�˻������ �����ϴ�.", "�ҷ����� ����", JOptionPane.ERROR_MESSAGE);
					} else {

						for (int i = data.length - 1; i >= 0; i--) {
							Object[] mod = new Object[data[0].length];
							for (int y = 0; y < data[i].length; y++) {
								mod[y] = data[i][y];
							}
							model1.addRow(mod);
						}
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "����� ���ų�, �����Դϴ�.", "�˻� ��� ����", JOptionPane.YES_OPTION);
				}
			}
		});

		bt_ok.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String start = (String) table1.getValueAt(table1.getSelectedRow(), 1);
				String goal = (String) table1.getValueAt(table1.getSelectedRow(), 2);
				String id = ID;
				RecodDAO dao = new RecodDAO();
				dao.Insert(start, goal, id);
			}
		});


		bt_del.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String start = (String) table2.getValueAt(table2.getSelectedRow(), 1);
				String goal = (String) table2.getValueAt(table2.getSelectedRow(), 2);
				String no = (String) table2.getValueAt(table2.getSelectedRow(), 0);
				String id = ID;
				RecodDAO dao = new RecodDAO();
				dao.Delite(start, goal, id, no);
			}
		});

		bt_all.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				RecodDAO dao = new RecodDAO();
				dao.Delall(ID);
				bt_re.doClick();
			}
		});
		bt_all2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				RecodDAO dao = new RecodDAO();
				dao.Delall2();
				bt_re.doClick();
			}
		});

		bt_go.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ComboSet(table1);
			}
		});
		bt_go2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ComboSet(table2);
			}
		});
	}
}
