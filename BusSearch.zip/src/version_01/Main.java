package version_01;



public class Main {
	public static final int SCREEN_WIDTH = 1500;
	public static final int SCREEN_HEIGHT = 1000;
	
	public static void main(String[] args) {
		LoginFrame ui = new LoginFrame();
		ui.run();
		
	}
}
