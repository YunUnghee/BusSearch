package version_01;

import javax.swing.JLabel;
import javax.swing.JPanel;

public interface BaseTab {
	void Print(JLabel la1, JLabel la2, JPanel p_main);
	void Panel1();
	void Panel2();
	void Panel3();
	void Panel4();
	void Panelcard();
	void Pmain();
	void ButtonEvent();
	void ReverseCard();
}
