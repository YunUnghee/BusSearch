package version_01;

public interface BaseInterface {
	void setBounds();
	void font();
	void run();
	void FrameAdd();
	void frameSet();
	void eventUp();
}
