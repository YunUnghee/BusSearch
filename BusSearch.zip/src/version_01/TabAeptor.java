package version_01;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumnModel;

@SuppressWarnings("serial")
public abstract class TabAeptor extends JFrame implements BaseTab {

	@Override
	public void Print(JLabel la1, JLabel la2, JPanel p_main) {
		ImageIcon icon = new ImageIcon(Main.class.getResource("../Image/green.png"));
		Image img = icon.getImage();
		Image changeImg = img.getScaledInstance(1400, 200, Image.SCALE_SMOOTH);
		ImageIcon changIcon = new ImageIcon(changeImg);
		la1 = new JLabel(changIcon);
		la1.setBounds(50, 720, 1400, 200);
		p_main.add(la1);
		icon = new ImageIcon(Main.class.getResource("../Image/LOGO.png"));
		img = icon.getImage();
		changeImg = img.getScaledInstance(1400, 180, Image.SCALE_SMOOTH);
		changIcon = new ImageIcon(changeImg);
		la2 = new JLabel(changIcon);
		la2.setBounds(50, 10, 1400, 180);
		p_main.add(la2);
	}

	void TableSET(JTable table) {
		DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer();
		dtcr.setHorizontalAlignment(SwingConstants.CENTER);
		TableColumnModel tcm = table.getColumnModel();
		for (int i = 0; i < tcm.getColumnCount(); i++) {
			tcm.getColumn(i).setCellRenderer(dtcr);
		}
	}
	
	
	public void Panel1() {
		// TODO Auto-generated method stub

	}

	
	public void Panel2() {
		// TODO Auto-generated method stub

	}

	
	public void Panel3() {
		// TODO Auto-generated method stub

	}

	
	public void Panel4() {
		// TODO Auto-generated method stub

	}

	
	public void Panelcard() {
		// TODO Auto-generated method stub

	}

	
	public void Pmain() {
		// TODO Auto-generated method stub

	}

	
	public void ButtonEvent() {
		// TODO Auto-generated method stub

	}

}
