package version_01;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class SignUp implements BaseInterface{
	private JFrame f = new JFrame("ȸ������");
	private JTextField sign = new JTextField(15);
	private JTextField email = new JTextField(30);
	private JPasswordField password = new JPasswordField(15);
	private JLabel sign_id = new JLabel("I   D  :  ");
	private JLabel sign_pass = new JLabel("PASS WORD  :  ");
	private JLabel sign_email = new JLabel("E-MAIL  :  ");
	private JButton sign_ok = new JButton("OK");
	private JButton sign_cl = new JButton("CANCLE");
	private JButton id_ch = new JButton("CHECK");
	private Font f1 = new Font("����", Font.PLAIN, 15);
	private Font f2 = new Font("����", Font.PLAIN, 25);
	private Color c = new Color(255, 255, 204);
	
	
	public void run() {
		this.font();
		this.setBounds();
		this.FrameAdd();
		this.eventUp();
		this.frameSet();

//		f.getContentPane().setBackground();
		
	}

	public void eventUp() {
		sign_ok.addActionListener(new ActionListener() { // ��ư�� ���� �� �ؽ�Ʈ�ʵ��� ���� �о�ͼ�
														 // �����ͺ��̽��� ����.
			public void actionPerformed(ActionEvent e) {
				try {
					String id = sign.getText();
					String pass = new String(password.getPassword());
					String mail = email.getText();
					String sign_ID = "";

					MemberDAO dao = new MemberDAO();
					ArrayList<MemberVo> login = dao.signup(id, pass, mail);

					for (int i = 0; i < login.size(); i++) {
						MemberVo data = (MemberVo) login.get(i);
						sign_ID = data.getSINGID();
					}
					if (id.equals(sign_ID)) {
						JOptionPane.showMessageDialog(null, "ȸ�����Կ� �����Ͽ����ϴ�.");
						LoginFrame lf = new LoginFrame();
						lf.run();
						f.dispose();
					}

				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "ȸ�����Կ� �����Ͽ����ϴ�.", "���� ����", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		sign_cl.addActionListener(new ActionListener() { // signUp ������ ���� ��, login ������ ����

			public void actionPerformed(ActionEvent e) {
				LoginFrame lf = new LoginFrame();
				lf.run();
				f.dispose();
			}
		});
		
		id_ch.addActionListener(new ActionListener() { // ID �ؽ�Ʈ�ʵ� ���� ������ ���̽��� ����Ǿ� �ִ��� �˻�

			public void actionPerformed(ActionEvent e) {
			 try {	
				String id = sign.getText();
				String ch_id = "";
				
				MemberDAO dao = new MemberDAO();
				ArrayList<MemberVo> check = dao.idcheck(id);
				
				for (int i = 0; i < check.size(); i++) {
					MemberVo data = (MemberVo) check.get(i);
					ch_id = data.getID();
				}
				if(id.equals(ch_id)) {
					JOptionPane.showMessageDialog(null, id+"�� ����� �� �ִ� ID �Դϴ�.");
				}
			}catch(Exception e2) {
				JOptionPane.showMessageDialog(null, "�̹� ���� ID�Դϴ�.", "ID �ߺ�", JOptionPane.ERROR_MESSAGE);
			}
			}
		});
		email.addKeyListener(new KeyAdapter() { //email �ؽ�Ʈ���� enter �Է��ϸ� ok��ư�� Ŭ����
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == 10) {
					sign_ok.doClick();
				}
			}
		});
		sign.addKeyListener(new KeyAdapter() { // �н������ʵ忡�� ����Ű�� �Է¹��� ���, Ȯ�� ��ư�� Ȱ��ȭ
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == 10) {
					id_ch.doClick();
					sign_pass.requestFocus(true);
				}
			}
		});
		sign_pass.addKeyListener(new KeyAdapter() { // �н������ʵ忡�� ����Ű�� �Է¹��� ���, Ȯ�� ��ư�� Ȱ��ȭ
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == 10) {
					sign_email.requestFocus(true);
				}
			}
		});
	}

	public void setBounds() {
		sign_id.setBounds(127, 50, 100, 50);
		sign.setBounds(190, 50, 150, 50);
		sign_pass.setBounds(60, 150, 150, 50);
		password.setBounds(190, 150, 150, 50);
		sign_email.setBounds(110, 250, 100, 50);
		email.setBounds(190, 250, 150, 50);
		sign_ok.setBounds(100, 400, 100, 50);
		sign_cl.setBounds(300, 400, 100, 50);
		id_ch.setBounds(360, 50, 100, 50);
		
	}

	public void font() {
		sign.setFont(f2);
		email.setFont(f1);
		password.setFont(f2);
		sign_id.setFont(f1);
		sign_pass.setFont(f1);
		sign_ok.setFont(f1);
		sign_cl.setFont(f1);
		sign_email.setFont(f1);
		id_ch.setFont(f1);
		
	}

	public void FrameAdd() {
		f.getContentPane().setBackground(c);
		f.setLayout(null);
		f.add(email);
		f.add(sign);
		f.add(password);
		f.add(sign_id);
		f.add(sign_pass);
		f.add(sign_email);
		f.add(sign_ok);
		f.add(sign_cl);
		f.add(id_ch);
	}

	public void frameSet() {
		f.setBackground(c);
		f.setSize(500, 500);
		f.setVisible(true);
		f.setLocationRelativeTo(null);
		f.setLayout(null);
		f.setResizable(false);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
}
