package version_01;

public class RecodVO {
	private String[][] Result;
	
	public RecodVO(String[][] Result) {
		this.Result = Result;
	}
	
	public String[][] getResult() {
		return Result;
	}
	
}
